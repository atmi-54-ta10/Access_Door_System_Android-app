package com.embeddedsystem.myapplication.guest;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.R;

import org.json.JSONException;
import org.json.JSONObject;


public class Home extends Fragment {

    boolean isLocked = false;
    TextView textClose, textDescription;
    ImageView doorImageView;
    Button btOpen, btCLose,presence;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home2, container, false);

        Calendar calendar = Calendar.getInstance();

        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("DoorStatus", Context.MODE_PRIVATE);
        isLocked = sharedPreferences.getString("status", "Locked").equals("Unlocked");

        SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
        String dayOfWeek = dayFormat.format(calendar.getTime());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");
        String currentDate = dateFormat.format(calendar.getTime());

        textDescription = rootView.findViewById(R.id.text_description);
        textClose = rootView.findViewById(R.id.text_close);
        btOpen = rootView.findViewById(R.id.bt_open);
        btCLose = rootView.findViewById(R.id.bt_close);
        doorImageView = rootView.findViewById(R.id.door_image);
        presence = rootView.findViewById(R.id.presence);


        textDescription.setText(dayOfWeek + ", " + currentDate);

        if (isLocked) {
            textClose.setText("Status Pintu: Terkunci");
            doorImageView.setImageResource(R.drawable.lock_door_hitam);
            btOpen.setEnabled(false);
            btCLose.setEnabled(false);
        } else {
            textClose.setText("Status Pintu: Terbuka");
            doorImageView.setImageResource(R.drawable.unlock_door_hitam);
            btOpen.setEnabled(false);
            btCLose.setEnabled(true);
        }

        btCLose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                closeDoor();
            }
        });

        btOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGuestDoor();
            }
        });

        updateDoorStatus();

        presence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ProgressDialog progressDialog = new ProgressDialog(getContext());
                progressDialog.setMessage("Loading...");
                progressDialog.show();

                // Panggil API menggunakan Volley
                RequestQueue queue = Volley.newRequestQueue(getContext());
                String url = "http://192.168.1.5:36356/master/status";

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                        (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    // Mendapatkan status dan lab dari respons JSON
                                    String status = response.getString("status");
                                    String lab = response.getString("Lab");

                                    progressDialog.dismiss();

                                    AlertDialog.Builder monitoringBuilder = new AlertDialog.Builder(getContext());
                                    monitoringBuilder.setTitle("Monitoring");
                                    monitoringBuilder.setMessage("Kehadiran Instruktur\nStatus: " + status + "\nLab: " + lab);
                                    monitoringBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                        }
                                    });
                                    monitoringBuilder.show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                    progressDialog.dismiss();
                                    Toast.makeText(getContext(), "Gagal mendapatkan data", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }, new Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {
                                error.printStackTrace();
                                progressDialog.dismiss();
                                Toast.makeText(getContext(), "Terjadi kesalahan koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                queue.add(jsonObjectRequest);
            }
        });

        return rootView;
    }

    private void closeDoor() {
        String url = "http://192.168.1.5:36356/door/close";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Toast.makeText(getContext(), "Pintu berhasil di tutup", Toast.LENGTH_SHORT).show();
                        SharedPreferences.Editor editor = requireActivity().getSharedPreferences("DoorStatus", Context.MODE_PRIVATE).edit();
                        editor.putString("status", "Unlocked");
                        editor.apply();
                        updateDoorStatus();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getContext(), "Gagal membuka pintu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Tambahkan request ke queue
        Volley.newRequestQueue(getContext()).add(jsonObjectRequest);
    }

    private void openGuestDoor() {
        String url = "http://192.168.1.5:36356/door/open";

        JSONObject requestData = new JSONObject();
        try {
            requestData.put("platform", "Android");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url, requestData,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String message = response.getString("message");
                            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
                            SharedPreferences.Editor editor = requireActivity().getSharedPreferences("DoorStatus", Context.MODE_PRIVATE).edit();
                            editor.putString("status", "Tidak Terkunci");
                            editor.apply();
                            updateDoorStatus(); // Pastikan metode ini mengupdate status pintu di UI
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getContext(), "Gagal membuka pintu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Tambahkan request ke queue
        Volley.newRequestQueue(getContext()).add(jsonObjectRequest);
    }



    private void updateDoorStatus() {
        // Buat URL endpoint untuk memeriksa status pintu
        String url = "http://192.168.1.5:36356/door/status";

        // Buat request menggunakan Volley
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // Ambil status kunci pintu dari respons JSON
                            int lockStatus = response.getInt("lock");
                            // Update tampilan sesuai dengan status pintu
                            if (lockStatus == 1) {
                                // Pintu terkunci
                                textClose.setText("Status Pintu: Terkunci");
                                doorImageView.setImageResource(R.drawable.lock_door_hitam);
                                btOpen.setEnabled(false);
                                btCLose.setEnabled(false);
                            } else {
                                // Pintu terbuka
                                textClose.setText("Status Pintu: Terbuka");
                                doorImageView.setImageResource(R.drawable.unlock_door_hitam);
                                btOpen.setEnabled(true);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getContext(), "Gagal memeriksa status pintu: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        // Tambahkan request ke queue
        Volley.newRequestQueue(getContext()).add(jsonObjectRequest);
    }
}