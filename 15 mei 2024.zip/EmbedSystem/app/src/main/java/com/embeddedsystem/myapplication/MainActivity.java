package com.embeddedsystem.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.embeddedsystem.myapplication.admin.About;
import com.embeddedsystem.myapplication.admin.Home;
import com.embeddedsystem.myapplication.admin.Profil;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    private SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        loadFragment(new Home());

        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.home) {
                selectedFragment = new Home();
            } else if (itemId == R.id.barcode) {
                selectedFragment = new About();
            } else if (itemId == R.id.cart) {
                Intent intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);

            }

            return loadFragment(selectedFragment);
        });

    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        // Jika ada fragmen yang dapat di-pop dari tumpukan kembali
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            // Jika tidak ada fragmen di tumpukan kembali, kembali ke halaman sebelumnya atau keluar dari aplikasi
            super.onBackPressed();
        }
    }
}

