package com.embeddedsystem.myapplication.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.MainActivity;
import com.embeddedsystem.myapplication.R;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Dashboard extends AppCompatActivity {

    private TextInputEditText usernameEditText, nameEditText, idnumberEditText, roleEditText, cardEditText;
    Button simpanButton,in,out;

    private Spinner jobEditText;
    private RequestQueue requestQueue;
    private String userID;

    private String url = "http://192.168.1.5:36356/user/sign_up";
    private String urlIn = "http://192.168.1.5:36356/master/card_in";
    private String urlOut = "http://192.168.1.5:36356/master/card_out";

    String[] jobItems = {"Job", "Student", "Instructor", "Staff", "Other"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        usernameEditText = findViewById(R.id.username);
        nameEditText = findViewById(R.id.full_name);
        idnumberEditText = findViewById(R.id.no_induk);
        jobEditText = findViewById(R.id.prodi_spinner);
        roleEditText = findViewById(R.id.txt_role);
        cardEditText = findViewById(R.id.txt_card);


        simpanButton = findViewById(R.id.btn_simpan);
        in = findViewById(R.id.btn_cardin);
        out = findViewById(R.id.btn_cardout);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, jobItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobEditText.setAdapter(adapter);

        requestQueue = Volley.newRequestQueue(this);

        simpanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String fullName = nameEditText.getText().toString();
                String noInduk = idnumberEditText.getText().toString();
                String role = roleEditText.getText().toString();
                String card = cardEditText.getText().toString();
                String prodi = jobEditText.getSelectedItem().toString();

                if (username.isEmpty() || fullName.isEmpty() || noInduk.isEmpty() ||  role.isEmpty() || card.isEmpty() || prodi.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Semua data harus diisi", Toast.LENGTH_SHORT).show();
                }  else {
                    signUp();
                    Intent intent = new Intent(Dashboard.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });

        in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendCardInRequest();
            }
        });

        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendCardOutRequest();
            }
        });


        usernameEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        nameEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        idnumberEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});

        // Menambahkan penanganan pesan toast jika karakter melebihi jumlah maksimum
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 16) {
                    Toast.makeText(Dashboard.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        nameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 16) {
                    Toast.makeText(Dashboard.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        idnumberEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 8) {
                    Toast.makeText(Dashboard.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

    }

    private void signUp() {
        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("username", usernameEditText.getText().toString());
            requestBody.put("name", nameEditText.getText().toString());
            requestBody.put("nomor_induk", idnumberEditText.getText().toString());
            requestBody.put("job", jobEditText.getSelectedItem().toString());
            requestBody.put("role", roleEditText.getText().toString());
            requestBody.put("card", cardEditText.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (roleEditText.getText().toString().equals("admin")) {
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, requestBody,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String message = response.getString("message");
                                Toast.makeText(Dashboard.this, message, Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(Dashboard.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                            Toast.makeText(Dashboard.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

            requestQueue.add(request);
        } else {
            // Handle other roles here
            Toast.makeText(Dashboard.this, "Role selain 'admin' tidak didukung saat ini", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendCardInRequest() {
        JSONObject requestBody = new JSONObject();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlIn, requestBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String message = response.getString("message");
                            Toast.makeText(Dashboard.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Dashboard.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(Dashboard.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);
    }

    private void sendCardOutRequest() {
        JSONObject requestBody = new JSONObject();
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, urlOut, requestBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String message = response.getString("message");
                            Toast.makeText(Dashboard.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Dashboard.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                        Toast.makeText(Dashboard.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(request);
    }


    }
