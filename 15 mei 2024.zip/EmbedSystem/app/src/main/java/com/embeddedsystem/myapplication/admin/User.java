package com.embeddedsystem.myapplication.admin;

public class User {

        private String _id;
        private String name;
        private String job;
        private String role;
        private String id_number;

    public User(String name, String job, String id_number) {
        this.name = name;
        this.job = job;
        this.id_number = id_number;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getjob() {
        return job;
    }

    public void setjob(String job) {
        this.job = job;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getid_number() {
        return id_number;
    }

    public void setid_number(String id_number) {
        this.id_number = id_number;
    }
}
