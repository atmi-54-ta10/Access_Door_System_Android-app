package com.embeddedsystem.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;

import com.embeddedsystem.myapplication.guest.About;
import com.embeddedsystem.myapplication.guest.Home;
import com.embeddedsystem.myapplication.guest.Profil;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Guest extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        loadFragment(new com.embeddedsystem.myapplication.guest.Home());

        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.home) {
                selectedFragment = new Home();
            } else if (itemId == R.id.barcode) {
                selectedFragment = new About();
            } else if (itemId == R.id.cart) {
                Intent intent = new Intent(Guest.this, Login.class);
                startActivity(intent);
            }

            return loadFragment(selectedFragment);
        });

    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }
}