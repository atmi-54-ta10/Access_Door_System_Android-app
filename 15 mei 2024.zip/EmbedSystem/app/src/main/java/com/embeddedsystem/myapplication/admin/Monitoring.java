package com.embeddedsystem.myapplication.admin;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Monitoring extends AppCompatActivity {

    private TextView textStatus, textMaster, textCard, textPanel, textEmTemperature;
    String status = "";
    String tap_card = "";
    String master_status ="";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoring2);

        textStatus = findViewById(R.id.text_status);
        textMaster = findViewById(R.id.master);
//        textMaster.setText("asd");
        textCard = findViewById(R.id.text_card);
        textPanel = findViewById(R.id.text_panel);
        textEmTemperature = findViewById(R.id.text_em_temperature);
//        fetchDataFromApi(lab_name,text_master,textStatus);


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        String url = "http://192.168.2.240:36356/door/status";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest
                (Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            int status = response.getInt("lock");
                            int card = response.getInt("tap_card");
                            if (status == 1){
                                textStatus.setText("LOCKED");
                            }
                            else if(status == 0) {
                                textStatus.setText("UNLOCKED");
                            }
                            textCard.setText(String.valueOf(card));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        textStatus.setText("Failed to fetch data");
                    }
                });

        String url2 = "http://192.168.2.240:36356/master/status";
        JsonObjectRequest jsonObjectRequest2 = new JsonObjectRequest
                (Request.Method.GET, url2, null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String masterStatus = response.getString("status");
                            textMaster.setText(masterStatus);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        textMaster.setText("Failed to fetch master data");
                    }
                });

        requestQueue.add(jsonObjectRequest2);
        requestQueue.add(jsonObjectRequest);


//        String url3 = "http://192.168.2.240:3635/data_suhu/tmp";
//
//        JSONObject postData = new JSONObject();
//        try {
//            postData.put("panel_temp", "your_panel_temp_value");
//            postData.put("emlock_temp", "your_em_temperature_value");
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        JsonObjectRequest jsonObjectRequest3 = new JsonObjectRequest
//                (Request.Method.POST, url3, postData, new Response.Listener<JSONObject>() {
//
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        try {
//                            String message = response.getString("message");
//                            textPanel.setText(message);
//                            // Mengambil nilai emlock_temp dari respons jika diperlukan
//                            String emLockTemp = postData.getString("emlock_temp");
//                            textEmTemperature.setText("Emlock Temperature: " + emLockTemp);
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }, new Response.ErrorListener() {
//
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        textPanel.setText("Failed to save data");
//                    }
//                });
//
//        requestQueue.add(jsonObjectRequest3);
    }


//    private void fetchDataFromApi(final TextView lab_name, final TextView text_master, final TextView text_door ) {
//        // URL API yang akan dipanggil
//        String url = "http://192.168.2.240:36356/master/status";
//
//        String url_door = "http://192.168.2.240:36356/door/status";
//
//        // Buat permintaan JSON Object Volley
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        try {
//                            // Ambil nilai "lab" dari objek JSON
////                            String lab = response.getString("lab");
//                            String stat_master = response.getString("status");
//                            // Set nilai "lab" ke dalam TextView
////                            lab_name.setText(lab);
////                            if (stat_master == 0)
//                            text_master.setText("Master Availability : "+ stat_master);
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        // Tanggapan gagal dari server
//                        textMaster.setText("Error: " + error.getMessage());
//                    }
//                });
//        JsonObjectRequest jsonObjectRequest_door = new JsonObjectRequest(Request.Method.GET, url_door, null,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        try {
//                            String doorLockStatus = response.getString("lock");
//
//
//                            if (doorLockStatus == "1") {
//                                text_door.setText("Door Status : Locked");
//                            } else {
//                                text_door.setText("Door Status : Unlocked");
//                            }
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        // Tanggapan gagal dari server
//                        lab_name.setText("Error: " + error.getMessage());
//                    }
//
//                });
//
//        // Tambahkan permintaan ke antrian Volley
//        RequestQueue requestQueue = Volley.newRequestQueue((this));
//        requestQueue.add(jsonObjectRequest);
//        requestQueue.add(jsonObjectRequest_door);
//
//    }

}
