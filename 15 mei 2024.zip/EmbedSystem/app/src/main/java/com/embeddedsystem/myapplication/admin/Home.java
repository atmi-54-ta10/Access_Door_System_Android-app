package com.embeddedsystem.myapplication.admin;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.R;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static android.content.Intent.getIntent;


public class Home extends Fragment {

    boolean isLocked = false;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        View dialogView = getLayoutInflater().inflate(R.layout.activity_controll, null);


        SharedPreferences loginPreferences = requireActivity().getSharedPreferences("AUTH", Context.MODE_PRIVATE);
//        String userId = loginPreferences.getString("userId", "");
        String name = loginPreferences.getString("name", "");
        String auth = loginPreferences.getString("token","");
        String role = loginPreferences.getString("role", "");

        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("DoorStatus", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("status", isLocked ? "Locked" : "Unlocked");
//        editor.putString("userId", userId);
        editor.apply();


        Button unlockButton = dialogView.findViewById(R.id.btn_unlock);
        Button lockButton = dialogView.findViewById(R.id.btn_lock);
        Button openButton = dialogView.findViewById(R.id.btn_open);
        Button closeButton = dialogView.findViewById(R.id.btn_close);
        TextView textStatus = dialogView.findViewById(R.id.text_status);
        TextView text_master= dialogView.findViewById(R.id.text_available);

        ImageView Menu = view.findViewById(R.id.dash);
        ImageView User = view.findViewById(R.id.user_data);
        ImageView Mon = view.findViewById(R.id.monitor);
        ImageView riwayat = view.findViewById(R.id.bt_history);
        TextView status = view.findViewById(R.id.text_status);
        TextView sett = view.findViewById(R.id.text_setting);
        TextView lab_name = view.findViewById(R.id.text_lab);
        fetchDataFromApi(lab_name,text_master,textStatus);
        status.setText(name);

        if (role != null) {
            if (role.equals("admin")) {
                Menu.setVisibility(View.GONE);
                sett.setVisibility(View.GONE);
            } else if (role.equals("master")) {
                Menu.setVisibility(View.VISIBLE);
                sett.setVisibility(View.VISIBLE);
            } else {
                Menu.setVisibility(View.GONE);
                sett.setVisibility(View.GONE);
                view.findViewById(R.id.bt_controll).setVisibility(View.VISIBLE);
            }
        } else {
            status.setText("Peran Tidak Diketahui");
            // Jika peran tidak diketahui, sembunyikan ImageView Menu
            Menu.setVisibility(View.GONE);
            // Jika peran tidak diketahui, tampilkan ImageView controll
            view.findViewById(R.id.bt_controll).setVisibility(View.VISIBLE);
        }



        try {
            ImageView controll = view.findViewById(R.id.bt_controll);
            TextView textDescription = view.findViewById(R.id.text_description);

            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat dayFormat = new SimpleDateFormat("EEEE");
            String dayOfWeek = dayFormat.format(calendar.getTime());

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy");
            String currentDate = dateFormat.format(calendar.getTime());

            textDescription.setText(dayOfWeek + ", " + currentDate);

            controll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    fetchDataFromApi(lab_name,text_master,textStatus);


                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());


                    if (role != null) {
                        if (role.equals("admin")) {

                        } else if (role.equals("master")) {

                        } else {
                            status.setText("Peran Lain");
                            view.findViewById(R.id.bt_controll).setVisibility(View.VISIBLE);
                        }
                    } else {
                        status.setText("Peran Tidak Diketahui");
                        view.findViewById(R.id.bt_controll).setVisibility(View.VISIBLE);
                    }


                    builder.setView(dialogView);

//                    updateDoorStatus(textStatus);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    JSONObject jsonBody = new JSONObject();
                    try {

                        jsonBody.put("platform", "Android");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                    lockButton.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                            String url = "http://192.168.2.240:36356/door/lock";
                            sendHttpRequest(url,  jsonBody);
                            fetchDataFromApi(lab_name,text_master,textStatus);


                        }
                    });


                    unlockButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            String url = "http://192.168.2.240:36356/door/unlock";
                            sendHttpRequest(url,  jsonBody);
                            fetchDataFromApi(lab_name,text_master,textStatus);


                        }
                    });

                    openButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            // Pastikan pintu sudah di-unlock sebelum membuka
                            String url = "http://192.168.2.240:36356/door/unlock";
                            sendHttpRequest(url,  jsonBody);
                            fetchDataFromApi(lab_name,text_master,textStatus);

                          }

                    });
                }

            });

        } catch (NullPointerException e) {
            e.printStackTrace();
            // Handle kesalahan, misalnya dengan menampilkan pesan kesalahan
            Toast.makeText(getContext(), "Terjadi kesalahan saat mencoba mengakses elemen UI", Toast.LENGTH_SHORT).show();
        }


        Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Dashboard.class);
                startActivity(i);
            }
        });


        User.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), UserData.class);
                startActivity(i);
            }
        });


        Mon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), Monitoring.class);
                startActivity(i);
            }
        });

        riwayat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getContext(), History.class);
                startActivity(i);
            }
        });

        return view;
    }

    private void fetchDataFromApi(final TextView lab_name, final TextView text_master, final TextView text_door ) {
        // URL API yang akan dipanggil
        String url = "http://192.168.2.240:36356/master/status";

        String url_door = "http://192.168.2.240:36356/door/status";

        // Buat permintaan JSON Object Volley
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            // Ambil nilai "lab" dari objek JSON
                            String lab = response.getString("lab");
                            String stat_master = response.getString("status");
                            // Set nilai "lab" ke dalam TextView
                            lab_name.setText(lab);
//                            if (stat_master == 0)
                            text_master.setText("Master Availability : "+ stat_master);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Tanggapan gagal dari server
                        lab_name.setText("Error: " + error.getMessage());
                    }
                });
        JsonObjectRequest jsonObjectRequest_door = new JsonObjectRequest(Request.Method.GET, url_door, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String doorLockStatus = response.getString("lock");

                            if (doorLockStatus == "1") {
                                text_door.setText("Door Status : Locked");
                            } else {
                                text_door.setText("Door Status : Unlocked");
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Tanggapan gagal dari server
                        lab_name.setText("Error: " + error.getMessage());
                    }

                });

        // Tambahkan permintaan ke antrian Volley
        RequestQueue requestQueue = Volley.newRequestQueue(requireContext());
        requestQueue.add(jsonObjectRequest);
        requestQueue.add(jsonObjectRequest_door);

    }

    private void sendHttpRequest(String url,  JSONObject jsonBody) {
        SharedPreferences loginPreferences = requireActivity().getSharedPreferences("AUTH", Context.MODE_PRIVATE);
        String auth = loginPreferences.getString("token","");



        RequestQueue queue = Volley.newRequestQueue(getContext());
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer " + auth);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url, jsonBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Tanggapan dari server
                        Toast.makeText(getContext(), response.toString(), Toast.LENGTH_SHORT).show();
                        // Tanggapan dari server dapat diinterpretasikan sesuai kebutuhan Anda
                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Kesalahan saat mengirim permintaan
                Toast.makeText(getContext(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return headers;
            }
        };

        // Tambahkan permintaan ke antrian
        queue.add(jsonObjectRequest);
//        queue.add(jsonObjectRequest);
//        queue.add(jsonObjectRequest_door);

    }



}