package com.embeddedsystem.myapplication.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class UserData extends AppCompatActivity {

    private Button tambahData;
    private ListView listView;
    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> idnumbers = new ArrayList<>();
    ArrayList<String> jobss = new ArrayList<>();
    ArrayList<String> roles = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_data);

        listView = findViewById(R.id.listViewUsers);

        tambahData = findViewById(R.id.btn_tambah);
        tambahData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(UserData.this);
                builder.setTitle("Choose User Type");
                builder.setMessage("");

                builder.setPositiveButton("Admin", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(getApplicationContext(), AddData.class);
                        startActivity(intent);
                    }
                });

                builder.setNegativeButton("Guest", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(getApplicationContext(), AddGuest.class);
                        startActivity(intent);
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "http://192.168.1.5:3635/user/all_guest"; // Sesuaikan URL_SERVER_ANDA dengan URL server Anda


        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            final ArrayList<String> userDataList = new ArrayList<>();
                            // Parsing JSON response
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject user = response.getJSONObject(i);
                                String identitas = user.getString("_id");
                                String name = user.getString("name");
                                String idnumbers = user.getString("id_number");
                                String jobss = user.getString("job"); //
                                String role = user.getString("role");

                                String userData = "ID: " + identitas + "\nName: " + name + "\nId Number: " + idnumbers + "\nJob: " + jobss + "\nRole: " + role + "\n";

                                userDataList.add(userData);
                            }

                            ArrayAdapter<String> adapter = new ArrayAdapter<>(UserData.this,
                                    android.R.layout.simple_list_item_1, userDataList);


                            listView.setAdapter(adapter);

                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    // Mendapatkan data pengguna yang diklik
                                    String userData = userDataList.get(position);

                                    // Parsing data pengguna untuk mendapatkan nilai masing-masing atribut
                                    String[] userDataArray = userData.split("\n");
                                    String identitas = userDataArray[0].substring(userDataArray[0].indexOf(":") + 2); // Menghilangkan "Name: " dari string
                                    String name = userDataArray[1].substring(userDataArray[1].indexOf(":") + 2); // Menghilangkan "Name: " dari string
                                    String nomorInduk = userDataArray[2].substring(userDataArray[2].indexOf(":") + 2); // Menghilangkan "Nomor Induk: " dari string
                                    String prodi = userDataArray[3].substring(userDataArray[3].indexOf(":") + 2); // Menghilangkan "Prodi: " dari string
                                    String role = userDataArray[4].substring(userDataArray[4].indexOf(":") + 2); // Menghilangkan "Role: " dari string

                                    // Meneruskan data ke halaman Edit
                                    Intent intent = new Intent(UserData.this, EditData.class);
                                    intent.putExtra("_id", identitas);
                                    intent.putExtra("name", name);
                                    intent.putExtra("nomor_induk", nomorInduk);
                                    intent.putExtra("prodi", prodi);
                                    intent.putExtra("role", role);
                                    startActivity(intent);
                                }
                            });

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Menampilkan pesan kesalahan jika terjadi kesalahan saat mengambil data dari API
                Toast.makeText(UserData.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
            }
        });

// Menambahkan request ke RequestQueue
        queue.add(jsonArrayRequest);

    }

}