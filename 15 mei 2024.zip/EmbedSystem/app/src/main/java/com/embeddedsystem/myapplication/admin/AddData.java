package com.embeddedsystem.myapplication.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.MainActivity;
import com.embeddedsystem.myapplication.R;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddData extends AppCompatActivity {

    private TextInputEditText usernameEditText, nameEditText, idnumberEditText, roleEditText, passwordEditText, cardEditText, txtkonfirmasi;
    private Button simpanButton, scan_data;

    private Spinner jobEditText;
    private RequestQueue requestQueue;
    private String userID;


    String[] jobItems = {"Job", "Staff", "Instructor", "Student", "Other"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        usernameEditText = findViewById(R.id.username);
        nameEditText = findViewById(R.id.full_name);
        idnumberEditText = findViewById(R.id.no_induk);
        jobEditText = findViewById(R.id.prodi_spinner);
        roleEditText = findViewById(R.id.txt_role);
        passwordEditText = findViewById(R.id.txt_password);
        cardEditText = findViewById(R.id.txt_card);
        txtkonfirmasi = findViewById(R.id.txt_konfirmasi);
        simpanButton = findViewById(R.id.btn_simpan);
        scan_data = findViewById(R.id.btn_scan);

        roleEditText.setText("admin");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, jobItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobEditText.setAdapter(adapter);

        requestQueue = Volley.newRequestQueue(this);

        scan_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scanData();
            }
        });

        simpanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String name = nameEditText.getText().toString();
                String idnumber = idnumberEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                String konfirmasiPassword = txtkonfirmasi.getText().toString();
                String role = roleEditText.getText().toString();
                String card = cardEditText.getText().toString();
                String job = jobEditText.getSelectedItem().toString();

                if (username.isEmpty() || name.isEmpty() || idnumber.isEmpty() || password.isEmpty() || konfirmasiPassword.isEmpty() || role.isEmpty() || card.isEmpty() || job.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Semua data harus diisi", Toast.LENGTH_SHORT).show();
                } else if (!password.equals(konfirmasiPassword)) {
                    Toast.makeText(getApplicationContext(), "Password tidak sama", Toast.LENGTH_SHORT).show();
                } else {
                    signUp();
                    Intent intent = new Intent(AddData.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });


        usernameEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        nameEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        idnumberEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        passwordEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});

        // Menambahkan penanganan pesan toast jika karakter melebihi jumlah maksimum
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 16) {
                    Toast.makeText(AddData.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        nameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 16) {
                    Toast.makeText(AddData.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        idnumberEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 8) {
                    Toast.makeText(AddData.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 16) {
                    Toast.makeText(AddData.this, "Maaf, karakter Anda melebihi jumlah maksimum", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }


    private void signUp() {
        String url = "http://192.168.1.5:3635/user/add_data"; // Sesuaikan URL_SERVER_ANDA dengan URL server Anda
        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("username", usernameEditText.getText().toString());
            requestBody.put("name", nameEditText.getText().toString());
            requestBody.put("id_number", idnumberEditText.getText().toString());
            requestBody.put("job", jobEditText.getSelectedItem().toString());

            // Mendapatkan peran pengguna sesuai dengan input
            String role = roleEditText.getText().toString();
            if (role.equalsIgnoreCase("admin")) {
                requestBody.put("role", "admin");
            } else {
                requestBody.put("role", "guest");
            }

            requestBody.put("password", passwordEditText.getText().toString());
            requestBody.put("card", cardEditText.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, requestBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String message = response.getString("message");
                            Toast.makeText(AddData.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(AddData.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                Toast.makeText(AddData.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        requestQueue.add(request);
    }


    private void scanData() {
        String scanUrl = "http://192.168.1.5:3635/add_card/" + userID;

        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("id", userID);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest scanRequest = new JsonObjectRequest(Request.Method.POST, scanUrl, requestBody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String message = response.getString("message");
                            Toast.makeText(AddData.this, message, Toast.LENGTH_SHORT).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(AddData.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        // Menambahkan request ke dalam request queue
        requestQueue.add(scanRequest);
    }

}
