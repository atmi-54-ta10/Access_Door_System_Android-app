package com.embeddedsystem.myapplication.admin;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.embeddedsystem.myapplication.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class History extends AppCompatActivity {

    private Button btnReport;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private Button btnTempLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        btnReport = findViewById(R.id.btn_report);
        btnTempLog = findViewById(R.id.temp_log);

        btnReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReportFormatDialog();
            }
        });

        btnTempLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTempLogFormatDialog();
            }
        });
    }

    private void checkPermissionAndDownloadExcel() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    PERMISSION_REQUEST_CODE);
        } else {
            // Permission has already been granted
            downloadExcel();
        }
    }

    private void downloadExcel() {
        // Replace this URL with your actual URL
        String excelUrl = "http://192.168.2.240:36356/action/excel";
        new DownloadExcelTask().execute(excelUrl);
    }

    private class DownloadExcelTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... urls) {
            String excelUrl = urls[0];
            try {
                URL url = new URL(excelUrl);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    InputStream in = urlConnection.getInputStream();
                    // Here you can read the InputStream and save it to a file
                    // Once the file is saved, you can open it using an Excel viewer library or intent
                } finally {
                    urlConnection.disconnect();
                }
            } catch (IOException e) {
                Log.e("DownloadExcelTask", "Error downloading Excel file: " + e.getMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // Here you can show a message or perform any action after the download is complete
            Toast.makeText(History.this, "Excel file downloaded successfully", Toast.LENGTH_SHORT).show();
        }
    }



    private void showReportFormatDialog() {
        String excel_url = "http://192.168.2.240:36356/action/excel";
        String pdf_url = "http://192.168.2.240:36356/action/pdf";
        String csv_url = "http://192.168.2.240:36356/action/csv";

        final CharSequence[] formats = {"Excel", "CSV", "PDF"};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Export Data Report");
        builder.setItems(formats, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedFormat = formats[which].toString();
                Toast.makeText(History.this, "Selected Report Format: " + selectedFormat, Toast.LENGTH_SHORT).show();
                // Check if the selected format is Excel, then open the URL
                if (selectedFormat.equals("Excel")) {
                    openURL(excel_url);
                }
                else if (selectedFormat.equals("PDF")){
                    openURL(pdf_url);
                }
                else if (selectedFormat.equals("CSV")){
                    openURL(csv_url);
                }
            }
        });
        builder.show();
    }

    private void openURL(String URL) {
        // Replace this URL with your actual URL
//        String formatUrl = URL;

        // Create an intent to open the URL in a browser
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(URL));

        // Check if there's an activity to handle this intent
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            // If no activity found to handle the intent
            Toast.makeText(this, "No app found to open URL", Toast.LENGTH_SHORT).show();
        }
    }


    private void showTempLogFormatDialog() {
        final CharSequence[] formats = {"Excel", "CSV", "PDF"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Export Data Temperature Log");
        builder.setItems(formats, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedFormat = formats[which].toString();
                Toast.makeText(History.this, "Selected Temperature Log Format: " + selectedFormat, Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                downloadExcel();
            } else {
                // Permission denied
                Toast.makeText(this, "Permission denied, cannot download Excel file", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

