package com.embeddedsystem.myapplication.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.MainActivity;
import com.embeddedsystem.myapplication.R;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddGuest extends AppCompatActivity {

    private TextInputEditText usernameEditText, idnumberEditText, roleEditText, cardEditText;
    private Button simpanButton;
    private Spinner jobEditText;
    private RequestQueue requestQueue;
    private String url = "http://192.168.1.9:36356/user/sign_up";

    String[] jobItems = {"Job", "Staff", "Instructor", "Student", "Other"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_guest);

        usernameEditText = findViewById(R.id.username);
        jobEditText = findViewById(R.id.prodi_spinner);
        idnumberEditText = findViewById(R.id.no_induk);
        roleEditText = findViewById(R.id.txt_role);
        cardEditText = findViewById(R.id.txt_card);
        simpanButton = findViewById(R.id.btn_simpan);

        roleEditText.setText("guest");

        requestQueue = Volley.newRequestQueue(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, jobItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        jobEditText.setAdapter(adapter);

        simpanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String noInduk = idnumberEditText.getText().toString();
                String role = roleEditText.getText().toString();
                String card = cardEditText.getText().toString();
                String prodi = jobEditText.getSelectedItem().toString();
                if (username.isEmpty() || noInduk.isEmpty() || role.isEmpty() || card.isEmpty() || prodi.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Semua data harus diisi", Toast.LENGTH_SHORT).show();
                } else {
                    signUp();
                    Intent i = new Intent(AddGuest.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });
    }

    private void signUp() {
        String url = "http://192.168.1.5:3635/user/add_data"; // Sesuaikan URL_SERVER_ANDA dengan URL server Anda
        JSONObject requestBody = new JSONObject();
        try {
            requestBody.put("name", usernameEditText.getText().toString());
            requestBody.put("job", jobEditText.getSelectedItem().toString());
            requestBody.put("id_number", idnumberEditText.getText().toString());
            requestBody.put("role", roleEditText.getText().toString());
            requestBody.put("card", cardEditText.getText().toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        if (roleEditText.getText().toString().equals("guest")) {
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, requestBody,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            try {
                                String message = response.getString("message");
                                Toast.makeText(AddGuest.this, message, Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(AddGuest.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            error.printStackTrace();
                            Toast.makeText(AddGuest.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

            requestQueue.add(request);
        } else if (roleEditText.getText().toString().equals("admin")) {
            Toast.makeText(AddGuest.this, "Role harus 'guest' untuk registrasi tamu", Toast.LENGTH_SHORT).show();
        }
    }


}