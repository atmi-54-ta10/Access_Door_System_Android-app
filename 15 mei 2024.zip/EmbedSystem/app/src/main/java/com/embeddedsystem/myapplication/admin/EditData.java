package com.embeddedsystem.myapplication.admin;

import androidx.appcompat.app.AppCompatActivity;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;


import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.embeddedsystem.myapplication.R;
import com.google.android.material.textfield.TextInputEditText;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EditData extends AppCompatActivity {
    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;
    TextInputEditText user, name, email,noid;
    Button save,delete;
    String id;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_user);
        fetchData();

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userList = new ArrayList<>();
        userAdapter = new UserAdapter(userList);
        recyclerView.setAdapter(userAdapter);

    }


        private void fetchData() {
            String url = "http://192.168.2.240:36356/user/all_user";
            JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            try {
                                for (int i = 0; i < response.length(); i++) {
                                    JSONObject userObject = response.getJSONObject(i);
                                    String numb = userObject.getString("id_number");
                                    String name = userObject.getString("name");
                                    String job = userObject.getString("job");

                                    userList.add(new User(name, job, numb));
                                }
                                userAdapter.notifyDataSetChanged();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(EditData.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
                }
            });

            RequestQueue queue = Volley.newRequestQueue(this);
            queue.add(jsonArrayRequest);
        }

//            JSONObject jsonObjectRequest = new JSONObject(Request.Method.GET, url, null,
//                    new Response.Listener<JSONObject>() {
//                        @Override
//                        public void onResponse(JSONObject response) {
//                            JSONObject jsonResponse = new JSONObject((Map) response);
//                            JSONArray userObject = null;
//                            try {
//                                userObject = response.toJSONArray(jsonResponse.names());
//                            } catch (JSONException e) {
//                                throw new RuntimeException(e);
//                            }
//
//                            for (int i = 0; i < userObject.length(); i++) {
//                                try {
//                                    JSONObject a = userObject.getJSONObject(i);
//                                    String numb = a.getString("id_number");
//                                    String name = a.getString("name");
//                                    String job = a.getString("job");
//
//                                    userList.add(new User(name, job, numb));
//                                } catch (JSONException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//                            userAdapter.notifyDataSetChanged();
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Toast.makeText(EditData.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
//                }
//            });
//
//            RequestQueue queue = Volley.newRequestQueue(this);
//            queue.add(jsonObjectRequest);
        }
//        Intent intent = getIntent();
//        id = intent.getStringExtra("_id");
//
//        String userName = intent.getStringExtra("name");
//        String fullName = intent.getStringExtra("id_number");
//        String emailAddress = intent.getStringExtra("job");
//
//        noid = findViewById(R.id.ni_id);
//        user = findViewById(R.id.username);
//        name = findViewById(R.id.full_name);
//        email = findViewById(R.id.email_addres);
//
//        save = findViewById(R.id.btn_simpan);
//        delete = findViewById(R.id.btn_hapus);
//
//        noid.setText(id);
//
//        user.setText(userName);
//        name.setText(fullName);
//        email.setText(emailAddress);
//
//        save.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // Memanggil fungsi updateUserData dengan parameter yang diperlukan
//                updateUserData(id, user.getText().toString(), name.getText().toString(), email.getText().toString());
//                Intent intent = new Intent(EditData.this, MainActivity.class);
//                startActivity(intent);
//            }
//        });
//
//        delete.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                deleteUserData(id);
//                Intent intent = new Intent(EditData.this, MainActivity.class);
//                startActivity(intent);
//            }
//        });
//    }
//
//    private void updateUserData(String id, final String userName, final String nomorInduk, final String prodi) {
//        String url = "http://192.168.2.240:36356/user/" + id;
//
//        JSONObject requestBody = new JSONObject();
//        try {
//            requestBody.put("name", userName);
//            requestBody.put("nomor_induk", nomorInduk);
//            requestBody.put("prodi", prodi);
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//
//        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, url, requestBody,
//                new Response.Listener<JSONObject>() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        // Handle response from the API
//                        try {
//                            String message = response.getString("message");
//                            Toast.makeText(EditData.this, message, Toast.LENGTH_SHORT).show();
//                            // Redirect to previous activity or perform any necessary action upon successful update
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                // Handle error response
//                Toast.makeText(EditData.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        // Add the request to the RequestQueue
//        RequestQueue queue = Volley.newRequestQueue(this);
//        queue.add(jsonObjectRequest);
//    }
//
//    private void deleteUserData(String id) {
//        String url = "http://192.168.2.240:36356/user/" + id;
//
//        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        // Handle response from the API
//                        try {
//                            JSONObject jsonResponse = new JSONObject(response);
//                            String message = jsonResponse.getString("message");
//                            Toast.makeText(EditData.this, message, Toast.LENGTH_SHORT).show();
//                            // Redirect to previous activity or perform any necessary action upon successful deletion
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                // Handle error response
//                Toast.makeText(EditData.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        // Add the request to the RequestQueue
//        RequestQueue queue = Volley.newRequestQueue(this);
//        queue.add(stringRequest);
//    }

